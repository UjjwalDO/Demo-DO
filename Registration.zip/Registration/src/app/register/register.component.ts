import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
//import { Register } from './register.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
/*
<div class="form-group">
    <label for="exampleInputEmail1"><b><span style="color: red;">*</span>Email</b></label>
    <input type="email" aria-describedby="emailHelp"  class="form-control" placeholder="*Enter Email" name="email" [(ngModel)]="login.email" email required #email="ngModel">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    <p *ngIf="email.touched && email.errors?.required">>>email is required</p>
    <p *ngIf="email.errors?.email">>>Email must be a valid email address</p>
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1"><b><span style="color: red;">*</span>Password</b></label>
    <input type="password" class="form-control" placeholder="*Enter Password" name="psw" [(ngModel)]="login.password" password required #password="ngModel">
    <p class="help-bpx" *ngIf="password.touched && !password.valid">>>password is required</p>
  </div>

*/

  //register = new  Register();

  constructor(private registerService : RegisterService) { }

  ngOnInit(): void {
  }

  onRegister(){

   // console.log(this.register);

  }

}
